//package org.firstinspires.ftc.teamcode._TeleOPs;
//
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//
//
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.CRServo;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.Servo;
//import org.firstinspires.ftc.teamcode.subsystems.Slides;
//
//public class Joenas extends LinearOpMode {
//    //Motors
//    private DcMotor FRW;
//    private DcMotor FLW;
//    private DcMotor BRW;
//    private DcMotor BLW;
//    //Motors
//    public void runOpMode() throws InterruptedException {
//        DcMotor FRW = hardwareMap.dcMotor.get("FRW");
//        DcMotor FLW = hardwareMap.dcMotor.get("FLW");
//        DcMotor BRW = hardwareMap.dcMotor.get("BRW");
//        DcMotor BLW = hardwareMap.dcMotor.get("BLW");
//        waitForStart();
//        while (opModeIsActive()) {
//
//            double y = -gamepad1.left_stick_y; // Remember, this is reversed
//            double x = gamepad1.left_stick_x; // Counteract imperfect strafing
//            double rx = .7 * (gamepad1.right_stick_x);
//
//
//            double i = 0;
//            double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
//            double frontLeftPower = (y + x + rx) / denominator;
//            double backLeftPower = (y - x + rx) / denominator;
//            double frontRightPower = (y - x - rx) / denominator;
//            double backRightPower = (y + x - rx) / denominator;
//
//            FLW.setPower(frontLeftPower * -1);
//            BLW.setPower(backLeftPower * -1);
//            FRW.setPower(frontRightPower * -1);
//            BRW.setPower(backRightPower * -1);
//
//
//
//        }
//    }
//}
