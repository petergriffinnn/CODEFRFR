package org.firstinspires.ftc.teamcode._TeleOPs;

import com.arcrobotics.ftclib.controller.PIDController;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Servo;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;



@TeleOp(name = "Field Centric Mecanum Drive")
public class FieldOrient extends LinearOpMode {

    String stage = "GROUND";


    public void delivery(HardwareMap hardwareMap) {


        double p = 0.1;
        double i = 0.0;
        double d = 0.0007;

        Slide = hardwareMap.get(DcMotorEx.class, "Slide");

        Slide.setDirection(DcMotorSimple.Direction.FORWARD); //this might not be needed; or the left slide should be the one being reversed

        Slide.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        Slide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);


        controller = new PIDController(p, i, d);
        reset();

    }

    public void stall() {

        Slide.setPower(0.1);

    }

    private DcMotor Slide;


    private PIDController controller;

    public void extend(double liftSpeed) {

        Slide.setPower(Math.abs(liftSpeed));


    }

    public void retract(double slideSpeed) {

        Slide.setPower(-Math.abs(slideSpeed));


    }


    public void moveToStage(String stage) {

        int slidePosition = Slide.getCurrentPosition();

        int Position[] = {145, 1000};
        String Stage[] = {"REST", "SCORE"};

        int stageIndex = Byte.MAX_VALUE;
        int res = 0;


        for (int i = 0; i < Stage.length; i++) {

            if (Stage[i].equals(stage)) {
                stageIndex = i;
                break;
            }
        }

        if (stageIndex != Byte.MAX_VALUE) {

            res = Position[stageIndex];
            double pid = controller.calculate(slidePosition, res);

            int error = res - slidePosition;

            double power = pid + 0.1;

            if (Math.abs(error) > 100) {

                Slide.setPower(power);




            }



        }
    }


    public void reset(){

        Slide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Slide.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

    }

    @Override
    public void runOpMode() throws InterruptedException {


        boolean pidOn = true;

        delivery(hardwareMap);


        //Motors
        DcMotor FRW = hardwareMap.dcMotor.get("FRW");
        DcMotor FLW = hardwareMap.dcMotor.get("FLW");
        DcMotor BRW = hardwareMap.dcMotor.get("BRW");
        DcMotor BLW = hardwareMap.dcMotor.get("BLW");
        FRW.setDirection(DcMotorSimple.Direction.REVERSE);
        BRW.setDirection(DcMotorSimple.Direction.REVERSE);

        DcMotor Intake = hardwareMap.dcMotor.get("Intake");
        DcMotor Slide = hardwareMap.dcMotor.get("Slide");

        DcMotor leftTower = hardwareMap.dcMotor.get("leftTower");
        DcMotor rightTower = hardwareMap.dcMotor.get("rightTower");

        //Servos
        Servo pp = hardwareMap.servo.get("pp"); //paper plane
        Servo emo = hardwareMap.servo.get("emo");
        Servo girl = hardwareMap.servo.get("girl");
        Servo adj = hardwareMap.servo.get("adj");
        Servo grimace = hardwareMap.servo.get("grimace");
        girl.setDirection(Servo.Direction.REVERSE);

        //IMU
        IMU imu = hardwareMap.get(IMU.class, "imu");

        IMU.Parameters parameters = new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.RIGHT,
                RevHubOrientationOnRobot.UsbFacingDirection.UP
        ));

        imu.initialize(parameters);
        imu.resetYaw();
        //Start Of Tele
        waitForStart();
        if (isStopRequested()) return;
        while (opModeIsActive()) {
//---------------------------------------------------IMU/DRIVE CODE--------------------------------------------------------------------------
            double y = -gamepad1.left_stick_y;
            double x = gamepad1.left_stick_x;
            double rx = .8 * gamepad1.right_stick_x;

            //resets imu
            if (gamepad1.cross) {
                imu.resetYaw();
            }

            double botHeading = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);

            double rotX = x * Math.cos(-botHeading) - y * Math.sin(-botHeading);
            double rotY = x * Math.sin(-botHeading) + y * Math.cos(-botHeading);

            rotX = rotX * 1.1;

            double denominator = Math.max(Math.abs(rotY) + Math.abs(rotX) + Math.abs(rx), 1);

            //LEFT POWER
            double FLWp = (rotY + rotX + rx) / denominator;
            double BLWp = (rotY - rotX + rx) / denominator;

            //RIGHT POWER
            double FRWp = (rotY - rotX - rx) / denominator;
            double BRWp = (rotY + rotX - rx) / denominator;

            FRW.setPower(FRWp * -.85);
            BRW.setPower(BRWp * -.85);
            FLW.setPower(FLWp * -.85);
            BLW.setPower(BLWp * -.85);

//--------------------------------------------CONTROLS-----------------------------------------------------------------------------
            //INTAKE
            if(gamepad2.right_bumper){
                Intake.setPower(.8);

            } else if (gamepad2.left_bumper){
                Intake.setPower(-.8);


            } else {
                Intake.setPower(0);


            }
//            if(gamepad2.options){
//                stage = "REST";
//                pidOn = true;
//            }
//            if(gamepad2.share){
//                stage = "SCORE";
//                pidOn = true;
//
//            }



            //Flipper-
            if(gamepad2.touchpad){
                emo.setPosition(.17); //increasing value makes it more down
                girl.setPosition(.17);
            }
            if(gamepad2.triangle){


                emo.setPosition(.19);
                girl.setPosition(.19);

            } else if (gamepad2.cross){

                girl.setPosition(.42);
                emo.setPosition(.42);

            }


            if (gamepad1.cross){
                grimace.setPosition(0);
            } else if (gamepad1.triangle) {
                grimace.setPosition(1);
            }
            // OUT TAKE ADJ
            if(gamepad2.dpad_down){
                adj.setPosition(.6);

            } else if(gamepad2.dpad_up){
                adj.setPosition(.07);

            } else if(gamepad2.dpad_right){
                adj.setPosition(.3);

            } else if (gamepad2.dpad_left){
                adj.setPosition(.85);

            }

            //Drone
            if (gamepad2.square){
                pp.setPosition(.7);
            } else if (gamepad2.circle){
                pp.setPosition(.9);
            }

            //SLIDE
            if(gamepad2.left_stick_y > .1){
                Slide.setPower(.7);
                //pidOn = false;

            } else if (-gamepad2.left_stick_y > .1) {
                Slide.setPower(-.7);
                //pidOn = false;



//            }else if(pidOn){
//                moveToStage(stage);
            } else {
                Slide.setPower(0);
//                pidOn = false;
            }

            //HANGING
            if(gamepad1.left_bumper){
                rightTower.setPower(-1);
                leftTower.setPower(-1);

            } else if (gamepad1.right_bumper){
                rightTower.setPower(1);
                leftTower.setPower(1);

            } else {
                rightTower.setPower(0);
                leftTower.setPower(0);

            }


        }


    }
}
