package org.firstinspires.ftc.teamcode._TeleOPs;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp
public class Testbed extends LinearOpMode {

    private Servo Servo;


    public void runOpMode() throws InterruptedException {

        //Motors
        Servo = hardwareMap.servo.get("Servo");



        waitForStart();
        while (!isStopRequested()){


            if(gamepad1.dpad_up){
                Servo.setPosition(.75);
            }
            if(gamepad1.dpad_down){
                Servo.setPosition(.5);
            }




            telemetry.addData("Awesome Time Elapsed", getRuntime());
            telemetry.update();

        }


    }
}

