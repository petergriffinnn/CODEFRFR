//package org.firstinspires.ftc.teamcode._TeleOPs;
//
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.CRServo;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.Servo;
//import org.firstinspires.ftc.teamcode.subsystems.Slides;
//
//
//@TeleOp
//public class PracticeJon extends LinearOpMode {
//
//    //Motors
//    private DcMotor FRW;
//    private DcMotor FLW;
//    private DcMotor BRW;
//    private DcMotor BLW;
//    private DcMotor Intake;
//    private DcMotor leftTower;
//    private DcMotor rightTower;
//
//    //Servos
//    private Servo pp;
//    private Servo flipper;
//    private Servo adj;
//    private CRServo bumper;
//
//    public void runOpMode() throws InterruptedException {
//
//        //Motors
//        DcMotor FRW = hardwareMap.dcMotor.get("FRW");
//        DcMotor FLW = hardwareMap.dcMotor.get("FLW");
//        DcMotor BRW = hardwareMap.dcMotor.get("BRW");
//        DcMotor BLW = hardwareMap.dcMotor.get("BLW");
//
//        DcMotor Intake = hardwareMap.dcMotor.get("Intake");
//        DcMotor Slide = hardwareMap.dcMotor.get("Slide");
//
//        DcMotor leftTower = hardwareMap.dcMotor.get("leftTower");
//        DcMotor rightTower = hardwareMap.dcMotor.get("rightTower");
//
//        //Servos
//        Servo pp = hardwareMap.servo.get("pp"); //paper plane
//        Servo flipper = hardwareMap.servo.get("flipper");
//        Servo adj = hardwareMap.servo.get("adj");
//        CRServo bumper = hardwareMap.crservo.get("bumper");
//
//        FLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        FRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//
//        BRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        BLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FRW.setDirection(DcMotorSimple.Direction.REVERSE);
//        BRW.setDirection(DcMotorSimple.Direction.REVERSE);
//
//        //  adj.setPosition(.2);
//
//
//        waitForStart();
//        while (opModeIsActive()){
//
//            if(gamepad2.left_stick_y>.1){
//                leftTower.setPower(0.8);
//            } else if(gamepad2.left_stick_y>-.1){
//                leftTower.setPower(-.8);
//            }  else {
//                leftTower.setPower(0);
//            }
//        } if (gamepad2.left_bumper)
//                Intake.setPower(.4);
//        else if (gamepad2.right_bumper){
//            Intake.setPower(-.4);
//            }else Intake.setPower(0);
//            }
//
//            }
//
