package org.firstinspires.ftc.teamcode.vision;

public enum View {
    YELLOW,
    RED,
    BLUE,
    BOUNDING_BOX
}
